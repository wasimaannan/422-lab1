class Node:
    def __init__(self, value=None):
        self.value = value
        self.children = []


def alpha_beta_pruning(node, depth, alpha, beta, m_p):
    if depth == 0 or node.value is not None:
        return node.value

    if m_p:
        max_node = float('-inf')
        for i in node.children:
            curr = alpha_beta_pruning(i, depth - 1, alpha, beta, False)
            max_node = max(max_node, curr)
            alpha = max(alpha, curr)
            if beta <= alpha:
                break
        return max_node
    else:
        min_node = float('inf')
        for i in node.children:
            curr = alpha_beta_pruning(i, depth - 1, alpha, beta, True)
            min_node = min(min_node, curr)
            beta = min(beta, curr)
            if beta <= alpha:
                break
        return min_node


def pacman_tree():
    leaf_values = [3, 6, 2, 3, 7, 1, 2, 0]
    leaf_nodes = [Node(value=v) for v in leaf_values]

    level_1 = [Node(), Node()]
    level_1[0].children = [leaf_nodes[0], leaf_nodes[1]]
    level_1[1].children = [leaf_nodes[2], leaf_nodes[3]]

    level_2 = [Node(), Node()]
    level_2[0].children = [leaf_nodes[4], leaf_nodes[5]]
    level_2[1].children = [leaf_nodes[6], leaf_nodes[7]]

    root = Node()
    root.children = [level_1[0], level_1[1], level_2[0], level_2[1]]

    return root


def pacman_game(cost):
    tree = pacman_tree()
    without_magic = alpha_beta_pruning(tree, 3, float('-inf'), float('inf'), True)

    left_tree = tree.children[0].children
    right_tree = tree.children[2].children

    left_subtree = Node()
    left_subtree.children = left_tree

    right_subtree = Node()
    right_subtree.children = right_tree

    magic_left = alpha_beta_pruning(left_subtree, 2, float('-inf'), float('inf'), True) - cost
    magic_right = alpha_beta_pruning(right_subtree, 2, float('-inf'), float('inf'), True) - cost

    if magic_left > without_magic or magic_right > without_magic:
        if magic_right >= magic_left:
            direction = "right"
            new_value = magic_right
        else:
            direction = "left"
            new_value = magic_left

        print(f"The new minimax value is {new_value}. Pacman goes {direction} and uses dark magic.")
    else:
        print(f"The minimax value is {without_magic}. Pacman does not use dark magic.")


inp = int(input("Enter the cost of using dark magic: ").strip())
pacman_game(inp)
# pacman_game(5)
