def minimax(node_idx, depth, is_pacman, values, alpha, beta):
    if depth == 3:
        return values[node_idx]

    if is_pacman:
        max_node = float('-inf')
        for i in range(2):
            curr = minimax(node_idx * 2 + i, depth + 1, False, values, alpha, beta)
            max_node = max(max_node, curr)
            alpha = max(alpha, max_node)
            if beta <= alpha:
                break
        return max_node
    else:
        min_node = float('inf')
        for i in range(2):
            curr = minimax(node_idx * 2 + i, depth + 1, True, values, alpha, beta)
            min_node = min(min_node, curr)
            beta = min(beta, min_node)
            if beta <= alpha:
                break
        return min_node


def pacman_game(cost):
    values = [3, 6, 2, 3, 7, 1, 2, 0]
    without_magic = minimax(0, 0, True, values, float('-inf'), float('inf'))

    left_max = max(values[:4])
    right_max = max(values[4:])

    magic_left = left_max - cost
    magic_right = right_max - cost

    if max(magic_left, magic_right) > without_magic:
        direction = "right" if magic_right >= magic_left else "left"
        new_value = max(magic_left, magic_right)
        print(f"The new minimax value is {new_value}. Pacman goes {direction} and uses dark magic.")
    else:
        print(f"The minimax value is {without_magic}. Pacman does not use dark magic.")


inp = int(input("Enter the cost of using dark magic: ").strip())
pacman_game(inp)
# pacman_game(5)
