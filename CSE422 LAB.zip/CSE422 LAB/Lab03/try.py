class Node:
    def __init__(self, value=None):
        self.value = value
        self.children = []


def alpha_beta_pruning(node, depth, alpha, beta, m_p):
    if depth == 0 or "value" in node:
        return node.get("value", 0)

    if m_p:
        max_node = float('-inf')
        for i in node["children"]:
            curr = alpha_beta_pruning(i, depth - 1, alpha, beta, False)
            max_node = max(max_node, curr)
            alpha = max(alpha, curr)
            if beta <= alpha:
                break
        return max_node
    else:
        min_node = float('inf')
        for i in node["children"]:
            curr = alpha_beta_pruning(i, depth - 1, alpha, beta, True)
            min_node = min(min_node, curr)
            beta = min(beta, curr)
            if beta <= alpha:
                break
        return min_node


def game_tree():
    root = {"children": []}

    for i in range(2):
        child = {"children": []}
        root["children"].append(child)

    leaf = [-1, 1, -1, 1]
    idx = 0
    for j in root["children"]:
        j["children"] = [{"value": leaf[idx]}, {"value": leaf[idx + 1]}]
        idx += 2
    return root


def mortal_kombat(first):
    player = first
    rounds = 3
    winners = []
    for i in range(1, rounds + 1):
        tree = game_tree()
        value = alpha_beta_pruning(tree, 5, float('-inf'), float('inf'), player == 0)
        winner = "Scorpion" if value == -1 else "Sub-Zero"
        winners.append(f"Winner of Round {i}: {winner}")
        player = 1 - player

    scorpion_wins = 0
    subzero_wins = 0

    for i in winners:
        if "Scorpion" in i:
            scorpion_wins += 1
        elif "Sub-Zero" in i:
            subzero_wins += 1

    if scorpion_wins > subzero_wins:
        game_winner = "Scorpion"
    else:
        game_winner = "Sub-Zero"

    print(f"Game Winner: {game_winner}")
    print(f"Total Rounds Played: {rounds}")

    for result in winners:
        print(result)


inp = input("Enter One single-digit number. (0 for Scorpion, 1 for Sub-Zero): ").strip()

if inp not in {"0", "1"}:
    print("Invalid input. Please enter 0 or 1.")
else:
    first_player = int(inp)
    mortal_kombat(first_player)
