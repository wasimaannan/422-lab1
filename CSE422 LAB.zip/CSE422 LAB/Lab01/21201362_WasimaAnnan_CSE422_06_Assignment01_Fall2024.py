import heapq
import math

hue_table = {}
graph = {}

with open("input.txt", "r") as f:
    inp = f.readlines()

for i in inp:
    node = i.strip().split()
    city = node[0].title()
    h = int(node[1])
    hue_table[city] = h
    n = node[2:]
    graph[city] = []
    for j in range(0, len(n), 2):
        neighbor = n[j].title()
        distance = int(n[j+1])
        graph[city].append((neighbor, distance))


def a_star(graph, hue_table, start, destination):
    visited = {}
    queue = [(hue_table[start], 0, start, [start])]

    while True:
        f_n, g_n, current, path = heapq.heappop(queue)
        if current not in visited or g_n < visited[current]:
            visited[current] = g_n
            for i, j in graph[current]:
                new_g_n = g_n + j
                f_n = new_g_n + hue_table[i]
                heapq.heappush(queue, (f_n, new_g_n, i, path + [i]))

        if current == destination:
            return path, g_n

        if not queue:
            return None, None


start = input("Start Node: ").title()
destination = input("Destination: ").title()

path, total_distance = a_star(graph, hue_table, start, destination)
if path is not None:
    print(f"Path: {' -> '.join(path)}")
    print(f"Total distance: {total_distance} km")
else:
    print("NO PATH FOUND")

#Bucharest