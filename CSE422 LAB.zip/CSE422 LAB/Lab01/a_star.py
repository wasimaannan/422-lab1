import heapq


# Updated parse_input function
def parse_input():
    graph = {}
    heuristics = {}

    # Open the file and read lines
    with open("input.txt", "r") as f1:
        inp = f1.readlines()

    # Process each line to fill the graph and heuristics
    for line in inp:
        data = line.strip().split()
        city = data[0]
        heuristic = int(data[1])
        heuristics[city] = heuristic
        neighbors = data[2:]

        # Add neighbors and distances for the current city
        graph[city] = []
        for i in range(0, len(neighbors), 2):
            neighbor = neighbors[i]
            distance = int(neighbors[i + 1])
            graph[city].append((neighbor, distance))

    return graph, heuristics


# A* Search Algorithm
def a_star_search(graph, heuristics, start, end):
    queue = [(0 + heuristics[start], 0, start, [start])]
    visited = set()

    while queue:
        f_cost, g_cost, current, path = heapq.heappop(queue)

        if current in visited:
            continue
        visited.add(current)

        if current == end:
            return path, g_cost

        for neighbor, distance in graph[current]:
            if neighbor not in visited:
                new_g_cost = g_cost + distance
                f_cost = new_g_cost + heuristics[neighbor]
                heapq.heappush(queue, (f_cost, new_g_cost, neighbor, path + [neighbor]))

    return None, None


# Main function to execute the search
def main():
    start = 'Arad'
    destination = 'Bucharest'

    # Parse the input file
    graph, heuristics = parse_input()

    # Run A* search
    path, total_distance = a_star_search(graph, heuristics, start, destination)

    # Print result
    if path:
        print(f"Path: {' -> '.join(path)}")
        print(f"Total distance: {total_distance} km")
    else:
        print("NO PATH FOUND")


# Run the main function
if __name__ == "__main__":
    main()
