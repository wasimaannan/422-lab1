import random
f = open("input.txt", "r")
N, T = [int(i) for i in f.readline().split()]
# print(N,T)


def chromosome(N, T):
  while True:
    chromo = [random.choice(["0", "1"]) for i in range(N*T)]
    if chromo != ["0"]*N*T:
      break
  return chromo


def crossover(ch1, ch2):
  cross_idx = random.randint(1, len(ch1) - 1)
  child1 = ch1[:cross_idx] + ch2[cross_idx:]
  child2 = ch2[:cross_idx] + ch1[cross_idx:]

  return child1, child2


def mutation(ch):
  mutation_idx = random.randint(1, len(ch) - 1)

  while True:
    if ch[mutation_idx] == "1":
      ch[mutation_idx] = "0"
    else:
      ch[mutation_idx] = "1"
    if ch != ["0"]*len(ch):
      break

  return ch


def fitness(ch, N, T):
  temp = [[None] * N for _ in range(T)]
  count = 0

  for i in range(len(temp)):
    for j in range(len(temp[0])):
      temp[i][j] = ch[count]
      count += 1

  fit_value = 0
  overlap = 0
  consistency = 0

  for i in range(len(temp)):
    x = temp[i].count("1")
    if x > 1:
      overlap += x-1

  for j in range(len(temp[0])):
    y = [0]*len(temp[0])
    for i in range(len(temp)):
      y[i] = temp[i][j]
    if y.count("1") < 1:
      consistency += 1
    elif y.count("1") > 1:
      consistency += y.count("1") - 1

  fit_value -= (overlap+consistency)

  return [fit_value, ch]


def genetic(N, T):
  ch1 = chromosome(N, T)
  ch2 = chromosome(N, T)
  population = [ch1, ch2]
  fitness_final = -float('inf')
  ch_final = []

  for j in range(900):
    fit = [fitness(ch1, N, T), fitness(ch2, N, T)]

    for i in range(len(fit)):
      if fit[i][0] > fitness_final:
        fitness_final = fit[i][0]
        ch_final = fit[i][1]

    child1, child2 = crossover(ch1, ch2)
    ch1 = mutation(child1)
    ch2 = mutation(child2)
    population = [ch1, ch2]

  return fitness_final, ch_final


def two_point_crossover(N, T):
  p1 = chromosome(N, T)
  p2 = chromosome(N, T)
  length = len(p1)

  point1 = random.randint(1, length - 2)
  point2 = random.randint(point1 + 1, length - 1)
  c1 = p1[:point1] + p2[point1:point2] + p1[point2:]
  c2 = p2[:point1] + p1[point1:point2] + p2[point2:]

  return c1, c2


a, b = genetic(N, T)
# print(a,b)
print("".join(b))
print(a)
k1, k2 = two_point_crossover(N, T)
print("".join(k1), "".join(k2))
