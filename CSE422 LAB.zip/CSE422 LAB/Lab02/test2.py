import random as rnd
f=open("input.txt","r")
N,T=[int(i) for i in f.readline().split()]
print(N,T)

# for i in range(N):
#   s=f.readline().strip()
#   if s not in map:
#     map[s]=i



def register(N,T):
  while True:
    reg=[rnd.choice(["0","1"]) for i in range(N*T)]
    if reg!=["0"]*N*T:
      break
  return reg

def crossover(reg1,reg2):
  crs_point=rnd.randint(1, len(reg1) - 1)
  # crs_point2=rnd.randint(crs_point1, len(reg1) - 1)
  child1 = reg1[:crs_point] + reg2[crs_point:]
  child2 = reg2[:crs_point] + reg1[crs_point:]
  return child1, child2



def mutation(reg):
  mut_point1=rnd.randint(1, len(reg) - 1)
  while True:
    if reg[mut_point1]=="1":
      reg[mut_point1]="0"
    else:
      reg[mut_point1]="1"
    if reg!=["0"]*len(reg):
      break
  return reg


def fitness(reg,N,T):
  temp = [[None] * N for _ in range(T)]
  iterator=0
  for i in range(len(temp)):
    for j in range(len(temp[0])):
      temp[i][j]=reg[iterator]
      iterator+=1

  fitness=0
  overlap=0
  consistency=0
  for i in range(len(temp)):
    a=temp[i].count("1")
    if a>1:
      overlap+=a-1


  for j in range(len(temp[0])):
    b=[0]*len(temp[0])
    for i in range(len(temp)):
      b[i]=temp[i][j]

    if b.count("1")<1:
      consistency+=1
    elif b.count("1")>1:
      consistency+=b.count("1")-1

  fitness-=(overlap+consistency)
  return [fitness,reg]




def genetic(N,T):
  reg1=register(N,T)
  reg2=register(N,T)
  popu=[reg1,reg2]
  res_fit=-float('inf')
  res_reg=[]
  for i in range(2):
    fit=[fitness(reg1,N,T),fitness(reg2,N,T)]

    for i in range(len(fit)):
      if fit[i][0]>res_fit:
        res_fit=fit[i][0]
        res_reg=fit[i][1]


    child1,child2=crossover(reg1,reg2)
    reg1=mutation(child1)
    reg2=mutation(child2)
    popu=[reg1,reg2]
  return res_fit,res_reg


a,b=genetic(N,T)
print(a,b)