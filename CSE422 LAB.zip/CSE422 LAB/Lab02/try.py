import random


# Helper functions
def initialize_population(pop_size, N, T):
    """Initialize a population of chromosomes."""
    chromosome_length = N * T
    return [
        "".join(random.choice("01") for _ in range(chromosome_length))
        for _ in range(pop_size)
    ]


def calculate_fitness(chromosome, N, T):
    """Calculate the fitness of a chromosome."""
    overlap_penalty = 0
    consistency_penalty = 0

    # Decode the chromosome into timeslots
    timeslots = [
        chromosome[i * N: (i + 1) * N] for i in range(T)
    ]

    # Calculate overlap penalty
    for timeslot in timeslots:
        overlap_penalty += max(0, sum(int(course) for course in timeslot) - 1)

    # Calculate consistency penalty
    course_counts = [0] * N
    for timeslot in timeslots:
        for i, bit in enumerate(timeslot):
            course_counts[i] += int(bit)

    for count in course_counts:
        consistency_penalty += abs(count - 1)

    # Fitness function
    fitness = -(overlap_penalty + consistency_penalty)
    return fitness


def select_parents(population, fitnesses):
    """Select two parents randomly based on fitness."""
    return random.choices(
        population, weights=[max(fitness, 1) for fitness in fitnesses], k=2
    )


def single_point_crossover(parent1, parent2):
    """Perform single-point crossover."""
    point = random.randint(1, len(parent1) - 1)
    child1 = parent1[:point] + parent2[point:]
    child2 = parent2[:point] + parent1[point:]
    return child1, child2


def two_point_crossover(parent1, parent2):
    """Perform two-point crossover."""
    point1, point2 = sorted(random.sample(range(1, len(parent1)), 2))
    child1 = (
            parent1[:point1] + parent2[point1:point2] + parent1[point2:]
    )
    child2 = (
            parent2[:point1] + parent1[point1:point2] + parent2[point2:]
    )
    return child1, child2


def mutate(chromosome, mutation_rate):
    """Mutate the chromosome."""
    return "".join(
        bit if random.random() > mutation_rate else str(1 - int(bit))
        for bit in chromosome
    )


# Genetic Algorithm
def genetic_algorithm(N, T, pop_size, max_iterations, mutation_rate):
    population = initialize_population(pop_size, N, T)
    for iteration in range(max_iterations):
        fitnesses = [calculate_fitness(chromo, N, T) for chromo in population]
        new_population = []

        for _ in range(pop_size // 2):
            parent1, parent2 = select_parents(population, fitnesses)
            child1, child2 = single_point_crossover(parent1, parent2)
            child1 = mutate(child1, mutation_rate)
            child2 = mutate(child2, mutation_rate)
            new_population.extend([child1, child2])

        population = new_population

        # Evaluate fitnesses
        fitnesses = [calculate_fitness(chromo, N, T) for chromo in population]
        max_fitness = max(fitnesses)

        # Print the best solution in the current generation
        print(f"Iteration {iteration + 1}: Best Fitness = {max_fitness}")
        if max_fitness == 0:  # Optimal solution found
            break

    # Final solution
    best_index = fitnesses.index(max(fitnesses))
    return population[best_index], max(fitnesses)


# Input
N = 3  # Number of courses
T = 3  # Number of timeslots
pop_size = 10
max_iterations = 50
mutation_rate = 0.1

# Run the algorithm
best_chromosome, best_fitness = genetic_algorithm(N, T, pop_size, max_iterations, mutation_rate)

print("\nBest Chromosome:", best_chromosome)
print("Best Fitness:", best_fitness)
