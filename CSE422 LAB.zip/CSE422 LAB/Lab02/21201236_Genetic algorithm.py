import random
from random import randint

f1=open("input_1.txt","r")
inp=f1.readline().strip().split()
length,target=int(inp[0]),int(inp[1])
players_runs={} #storing player names and corresponding runs
for i in range(length):
    inp=f1.readline().strip().split()
    players_runs[inp[0]]=int(inp[1])

population_size=10 #initializing
maxIteration=1000 #initializing

initial_population=[]
def initialPopulation_generator(lis):
    population=[]
    for i in range(length):
        population.append(randint(0,1))
    return population

while len(initial_population)!=population_size:
    initial_population+=[initialPopulation_generator(initial_population)]

def fitness(lis):
    sum=0
    for x in range(len(lis)):
        if lis[x]==0:
            continue
        else:
            pl=list(players_runs.keys())[x]
            sum+=players_runs[pl]
    return sum

def selection(popl):
    c_1,c_2=random.sample(popl,2)
    return c_1,c_2

def crossover(f_chr,m_chr):
    crossover_point=randint(1,length-1)

    off_1=f_chr[0:crossover_point]+m_chr[crossover_point:]
    off_2=m_chr[0:crossover_point]+f_chr[crossover_point:]

    return off_1,off_2


def mutation(gene):
    idx=randint(0,length-1)
    if gene[idx]==0:
        gene[idx]=1
    else:
        gene[idx]=0
    return gene

def geneticAlgorithm(initial_population,target):
    population=initial_population.copy()
    
    for _ in range(maxIteration):
        new_population=[]
        for i in range(population_size):
            
            offsprings=[]
            children=selection(population)
            off1,off2=crossover(children[0],children[1])
            offsprings.append(off1)
            offsprings.append(off2)
            
            prob=randint(0,2) #mutation probability

            if prob==2: #both chromosomes are mutated
                child1=mutation(off1)
                child2=mutation(off2)
            elif prob==1: #only one chromosome is mutated
                c_1=random.sample(offsprings,1)
                if c_1==off1:
                    child1=mutation(off1)
                    child2=off2
                else:
                    child2=mutation(off2)
                    child1=off1
            elif prob==0: #no mutation
                child1=off1
                child2=off2

            new_population.append(child1)
            new_population.append(child2)

        population=new_population #updating the population with children
        
        fitness_list=[]
        for i in range(len(population)):
            ind_fit=fitness(population[i])
            fit_dif=abs(target-ind_fit)
            fitness_list.append(fit_dif)
        
        sorted_fit = sorted(list(zip(fitness_list,population)),key=lambda x:x[0]) #sorting on the basis of fitness
        sorted_fit=sorted_fit[:population_size] #cutting down children to initial population size
        population=[i[1] for i in sorted_fit]
        
        if sorted_fit[0][0]==0:
            break
        else:
            continue
    if sorted_fit[0][0]==0:
        return sorted_fit[0][1]
    else:
        return -1
            
        
print(list(players_runs.keys()))      
    
res=geneticAlgorithm(initial_population,target)

if res==-1:
    print(res)
else:
    s=""
    for bin in res:
        s+=str(bin)
    print(s)
f1.close()